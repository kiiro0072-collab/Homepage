import { useEffect, useRef, useState } from 'react'
import {
  MapContainer, TileLayer, CircleMarker, Rectangle, useMap,
} from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import './App.css'

const ZOOM_MIN = 3
const ZOOM_MAX = 15
const API = ''

type TileRect = { x1: number; y1: number; x2: number; y2: number }

function fmtSec(s: number): string {
  if (!Number.isFinite(s) || s < 0) return '--'
  s = Math.round(s)
  let out = ''
  if (s >= 3600) { out += Math.floor(s / 3600) + '時間'; s %= 3600 }
  if (s >= 60) { out += Math.floor(s / 60) + '分'; s %= 60 }
  if (!out || s > 0) { out += s + '秒' }
  return out
}

function fmtClock(d: Date): string {
  const p = (n: number) => String(n).padStart(2, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

function lonToTileX(lon: number, z: number) {
  return Math.floor((lon + 180) / 360 * 2 ** z)
}
function latToTileY(lat: number, z: number) {
  const r = (lat * Math.PI) / 180
  return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 2 ** z)
}
function tileXToLon(x: number, z: number) {
  return x / 2 ** z * 360 - 180
}
function tileYToLat(y: number, z: number) {
  const n = Math.PI * (1 - 2 * y / 2 ** z)
  return (180 / Math.PI) * Math.atan(Math.sinh(n))
}
function rectCorners(r: TileRect, z: number): L.LatLngTuple[] {
  const lo = [tileYToLat(r.y2 + 1, z), tileXToLon(r.x1, z)] as L.LatLngTuple
  const hi = [tileYToLat(r.y1, z), tileXToLon(r.x2 + 1, z)] as L.LatLngTuple
  return [lo, hi]
}

function RectangleSnap({ rect, zoom, color }: { rect: TileRect; zoom: number; color: string }) {
  if (rect.x1 < 0) return null
  const corners = rectCorners(rect, zoom)
  return (
    <Rectangle
      bounds={corners}
      pathOptions={{ color, weight: 2, fillColor: color, fillOpacity: 0.15, dashArray: '8 6' }}
    />
  )
}

function ClickHandler({ onPick }: { onPick: (lat: number, lon: number, zoom: number) => void }) {
  const map = useMap()
  const onPickRef = useRef(onPick)
  onPickRef.current = onPick
  useEffect(() => {
    const h = (e: L.LeafletMouseEvent) => onPickRef.current(e.latlng.lat, e.latlng.lng, map.getZoom())
    map.on('click', h)
    return () => { map.off('click', h) }
  }, [map])
  return null
}

function ZoomSync({ onZoom }: { onZoom: (z: number) => void }) {
  const map = useMap()
  useEffect(() => {
    const h = () => onZoom(map.getZoom())
    map.on('zoomend', h)
    return () => { map.off('zoomend', h) }
  }, [map, onZoom])
  return null
}

function MapPanel({ rect, rectZoom, first, onPick, onZoom }: {
  rect: TileRect | null
  rectZoom: number
  first: { x: number; y: number; z: number } | null
  onPick: (lat: number, lon: number, z: number) => void
  onZoom: (z: number) => void
}) {
  return (
    <MapContainer
      center={[35.0, 137.0]}
      zoom={12}
      minZoom={ZOOM_MIN}
      maxZoom={ZOOM_MAX}
      doubleClickZoom={false}
      style={{ width: '100%', height: '100%' }}
    >
      <TileLayer
        attribution='&copy; OpenStreetMap contributors'
        url={`${API}/api/tiles/{z}/{x}/{y}.png`}
        maxZoom={ZOOM_MAX}
      />
      <ZoomSync onZoom={onZoom} />
      <ClickHandler onPick={onPick} />
      {rect && <RectangleSnap rect={rect} zoom={rectZoom} color="#e62222" />}
      {first && (
        <CircleMarker
          interactive={false}
          center={[tileYToLat(first.y + 0.5, first.z), tileXToLon(first.x + 0.5, first.z)]}
          radius={10}
          pathOptions={{ color: '#e62222', weight: 2, fillColor: '#e62222', fillOpacity: 0.6 }}
        />
      )}
    </MapContainer>
  )
}

export default function App() {
  const [rect, setRect] = useState<TileRect | null>(null)
  const [rectZoom, setRectZoom] = useState(12)
  const [first, setFirst] = useState<{ x: number; y: number; z: number } | null>(null)
  const [zoom, setZoom] = useState(12)
  const [genName, setGenName] = useState('world_webui')
  const [outDir, setOutDir] = useState('')
  const [status, setStatus] = useState('地図上をクリックして1点目と2点目を指定してください')
  const [progress, setProgress] = useState(0)
  const [msg, setMsg] = useState('')
  const [eta, setEta] = useState('')
  const [etaAt, setEtaAt] = useState('')
  const [generating, setGenerating] = useState(false)
  const [spawnX, setSpawnX] = useState('')
  const [spawnZ, setSpawnZ] = useState('')
  const [downloadReady, setDownloadReady] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const startRef = useRef(0)

  const onPick = (lat: number, lon: number, z: number) => {
    const tx = lonToTileX(lon, z)
    const ty = latToTileY(lat, z)
    if (!first) {
      setFirst({ x: tx, y: ty, z })
      setRect(null)
      return
    }
    if (first.z !== z) {
      setFirst({ x: tx, y: ty, z })
      setRect(null)
      return
    }
    setRect({ x1: Math.min(first.x, tx), y1: Math.min(first.y, ty), x2: Math.max(first.x, tx), y2: Math.max(first.y, ty) })
    setRectZoom(z)
    setFirst(null)
  }

  const info = rect ? (() => {
    const cols = rect.x2 - rect.x1 + 1
    const rows = rect.y2 - rect.y1 + 1
    const latLo = tileYToLat(rect.y2 + 1, rectZoom)
    const latHi = tileYToLat(rect.y1, rectZoom)
    const lonLo = tileXToLon(rect.x1, rectZoom)
    const lonHi = tileXToLon(rect.x2 + 1, rectZoom)
    return { cols, rows, latLo, latHi, lonLo, lonHi }
  })() : null

  const generate = async () => {
    if (!rect || generating) return
    const cols = rect.x2 - rect.x1 + 1
    const rows = rect.y2 - rect.y1 + 1
    setGenerating(true)
    setProgress(0)
    setMsg('')
    setEta('')
    setEtaAt('')
    setStatus('生成を開始します...')
    setDownloadReady(false)
    startRef.current = Date.now()

    const sx = parseInt(spawnX, 10)
    const sz = parseInt(spawnZ, 10)

    try {
      const res = await fetch(`${API}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          zoom: rectZoom,
          minX: rect.x1,
          minY: rect.y1,
          cols,
          rows,
          worldDir: outDir || genName,
          ...(Number.isFinite(sx) ? { spawnX: sx } : {}),
          ...(Number.isFinite(sz) ? { spawnZ: sz } : {}),
        }),
      })
      const data = await res.json()
      if (!data.ok) {
        setStatus('エラー: ' + (data.error ?? '不明なエラー'))
        setGenerating(false)
        return
      }
      const runId = data.runId ?? 0

      // 生成が始まってから SSE を購読し、完了(fraction=1)まで待つ
      const evt = new EventSource(`${API}/api/progress`)
      evt.onmessage = (e) => {
        const d = JSON.parse(e.data)
        // 古い/別の生成からの進捗イベントは無視
        if (d.runId !== undefined && d.runId !== runId) return
        const f = d.fraction ?? 0
        setProgress(Math.round(f * 100))
        setMsg(d.message ?? '')
        // 残り時間と完了予定時刻を推定 (fraction > 2% の時のみ)
        if (f > 0.02) {
          const elapsed = (Date.now() - startRef.current) / 1000
          const total = elapsed / f
          const remain = Math.max(0, total - elapsed)
          setEta(fmtSec(remain))
          setEtaAt(fmtClock(new Date(Date.now() + remain * 1000)))
        }
        if (f >= 1.0 || (d.message ?? '').startsWith('エラー')) {
          evt.close()
          setGenerating(false)
          setProgress(100)
          setEta('')
          setEtaAt('')
          if (f >= 1.0) setDownloadReady(true)
          setStatus(d.message ?? '生成完了: ' + data.worldDir)
        }
      }
      evt.onerror = () => {
        evt.close()
        setGenerating(false)
        setStatus('エラー: 進捗の受信に失敗しました')
      }
    } catch (err) {
      setGenerating(false)
      setStatus('エラー: ' + (err as Error).message)
    }
  }

  const download = async () => {
    if (generating || downloading) return
    setDownloading(true)
    setStatus('ZIPを作成中...')
    try {
      const res = await fetch(`${API}/api/download`)
      if (!res.ok) {
        let msg = 'ダウンロードに失敗しました'
        try {
          const d = await res.json()
          if (d.error) msg = d.error
        } catch { /* JSONでない場合は既定メッセージ */ }
        setStatus('エラー: ' + msg)
        return
      }
      const blob = await res.blob()
      let name = (outDir || genName || 'world').split(/[\\/]/).filter(Boolean).pop() || 'world'
      const cd = res.headers.get('Content-Disposition')
      if (cd) {
        const m = cd.match(/filename="?([^"]+)"?/)
        if (m) name = m[1]
      }
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = name.endsWith('.zip') ? name : name + '.zip'
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      setStatus('ダウンロード完了: ' + name + '.zip')
    } catch (err) {
      setStatus('エラー: ' + (err as Error).message)
    } finally {
      setDownloading(false)
    }
  }

  const statusClass = status.startsWith('エラー') ? 'err' : status.startsWith('生成完了') ? 'ok' : ''

  return (
    <div className="app">
      <MapPanel rect={rect} rectZoom={rectZoom} first={first} onPick={onPick} onZoom={setZoom} />
      <div className="side">
        <h1>OSM ワールド生成</h1>
        <div className="field">
          <label>出力ワールド名/パス</label>
          <input value={genName} onChange={(e) => setGenName(e.target.value)} placeholder="world_webui" />
          <input value={outDir} onChange={(e) => setOutDir(e.target.value)} placeholder="絶対パス(省略可)" />
        </div>
        <div className="info">
          <div>ズーム: {zoom}</div>
          {info ? (
            <>
              <div>タイル: {info.cols} x {info.rows} = {info.cols * info.rows}枚</div>
              <div>マップ: {info.cols * 256} x {info.rows * 256} ブロック</div>
              <div>緯度: {info.latLo.toFixed(4)}〜{info.latHi.toFixed(4)}</div>
              <div>経度: {info.lonLo.toFixed(4)}〜{info.lonHi.toFixed(4)}</div>
            </>
          ) : (
            <div>範囲未選択</div>
          )}
        </div>
        <div className="field">
          <label>スポーン座標 (ブロック, 省略時は中央)</label>
          <div style={{ display: 'flex', gap: '8px' }}>
            <input value={spawnX} onChange={(e) => setSpawnX(e.target.value)} placeholder="X" inputMode="numeric" />
            <input value={spawnZ} onChange={(e) => setSpawnZ(e.target.value)} placeholder="Z" inputMode="numeric" />
          </div>
        </div>
        <button className="generate" disabled={!info || generating} onClick={generate}>
          {generating ? '生成中...' : 'ワールドを生成'}
        </button>
        <button className="download" disabled={!downloadReady || generating || downloading} onClick={download}>
          {downloading ? 'ZIP作成中...' : 'ワールドをダウンロード (ZIP)'}
        </button>
        {generating && (
          <>
            <div className="bar"><div className="fill" style={{ width: `${progress}%` }} /></div>
            <div className="msg">{msg}</div>
            <div className="eta">残り時間: {eta} / 完了予定: {etaAt}</div>
          </>
        )}
        <div className={`status ${statusClass}`}>{status}</div>
        <div className="help">
          <ul>
            <li>クリック: 1点目・2点目を指定 (2点で矩形確定)</li>
            <li>ホイール/ダブルクリック: ズーム</li>
            <li>ドラッグ: 移動</li>
            <li>1点目と異ズームの2点目は拒否</li>
            <li>生成は1024x1024ブロックのグリッド単位で行われます</li>
            <li>生成完了後「ダウンロード」でZIPを保存できます</li>
          </ul>
        </div>
      </div>
    </div>
  )
}