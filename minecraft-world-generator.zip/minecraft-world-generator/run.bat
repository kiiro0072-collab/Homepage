@echo off
java -jar untitled10.jar --webui